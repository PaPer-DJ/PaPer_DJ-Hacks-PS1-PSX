The script will recursively search through whichever directory
it is in, as well as subdirectories, and auto convert
bin+cue, as well as iso files, to chd files:)  You can just copy
and paste, or drag and drop bin+cue and/or or iso files into the
directory containing chdman + _km_bin_cue_&_iso_to_chd.bat, as well:)

ONLY use this for Sega-CD & Turbografx-CD & PC-FX Games on NESC/SNESC,
for now!  This may change in the future.  This will help MANY
games run NON-USB-HOST!  But, obviously, CD Based Games are
still best suited for USB-HOST!

Mednafen Saturn also supports CHD files, so can also be used with
this set-up!

Dreamcast works, but is trickier to do, depending on source files!!!

DREAMCAST = _km Reicast = /bin/reicast

PC-FX = _km Mednafen PC-FX = /bin/pcfx

SEGA-CD = _km Genesis Plus GX = /bin/segacd

TURBOGRAFX-CD = _km Mednafen PCE Fast = /bin/pcecd

KMFDManic:)